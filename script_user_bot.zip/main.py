from pyrogram import Client, filters
from pyrogram.errors import FloodWait

print("Библиотека Pyrogramm импортированна успешно!")
print("Запуск скрипта...")
print()
print("_______________________________")
print("Перед запуском, убедитесь что вы создали файл config.ini, иначе скрипт не запустится!")
print()
print("_______________________________")

from pyrogram.types import ChatPermissions

import time
from time import sleep
import random

app = Client("my_account")

print("Скрипт запущен")

# Команда type
@app.on_message(filters.command("t", prefixes=".") & filters.me)
def type(_, msg):
	orig_text = msg.text.split(".t ", maxsplit=1)[1]
	text = orig_text
	tbp = "" # to be printed
	typing_symbol = "▒"

	while(tbp != orig_text):
		try:
			msg.edit(tbp + typing_symbol)
			sleep(0.01) # 10 ms

			tbp = tbp + text[0]
			text = text[1:]

			msg.edit(tbp)
			sleep(0.01)

		except FloodWait as e:
			sleep(e.x)

# Команда взлома пентагона
@app.on_message(filters.command("hack", prefixes=".") & filters.me)
def hack(_, msg):
	perc = 0

	while(perc < 100):
		try:
			text = "👮‍ Взлом пентагона в процессе ..." + str(perc) + "%"
			msg.edit(text)

			perc += random.randint(1, 3)
			sleep(0.1)

		except FloodWait as e:
			sleep(e.x)

	msg.edit("🟢 Пентагон успешно взломан!")
	sleep(3)

	msg.edit("👽 Поиск секретных данных об НЛО ...")
	perc = 0

	while(perc < 100):
		try:
			text = "👽 Поиск секретных данных об НЛО ..." + str(perc) + "%"
			msg.edit(text)

			perc += random.randint(1, 5)
			sleep(0.15)

		except FloodWait as e:
			sleep(e.x)

	msg.edit("🦖 Найдены данные о существовании динозавров на земле!")

@app.on_message(filters.command("mut", prefixes=".") & filters.me)
def thanos(_, msg):
    chat = msg.text.split(".thanos ", maxsplit=1)[1]

    members = [
        x
        for x in app.iter_chat_members(chat)
        if x.status not in ("administrator", "creator")
    ]

    random.shuffle(members)

    app.send_message(chat, "Щелчок Таноса для мутинга ;) ... *щёлк*")

    for i in range(len(members) // 2):
        try:
            app.restrict_chat_member(
                chat_id=chat,
                user_id=members[i].user.id,
                permissions=ChatPermissions(),
                until_date=int(time.time() + 86400),
            )
            app.send_message(chat, "Исчез " + members[i].user.first_name)
        except FloodWait as e:
            print("> waiting", e.x, "seconds.")
            time.sleep(e.x)

    app.send_message(chat, "Но какой ценой?")

app.run()